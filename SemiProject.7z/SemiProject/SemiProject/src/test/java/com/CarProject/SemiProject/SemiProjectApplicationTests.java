package com.CarProject.SemiProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SemiProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
