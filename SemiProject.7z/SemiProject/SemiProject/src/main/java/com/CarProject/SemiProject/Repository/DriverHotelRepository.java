package com.CarProject.SemiProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CarProject.SemiProject.Entity.DriverHotel;

public interface DriverHotelRepository extends JpaRepository<DriverHotel, Integer> {

}
