package com.CarProject.SemiProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CarProject.SemiProject.Entity.DriverDetails;

public interface DriverDetailsRepository extends JpaRepository<DriverDetails, Integer> {

}
