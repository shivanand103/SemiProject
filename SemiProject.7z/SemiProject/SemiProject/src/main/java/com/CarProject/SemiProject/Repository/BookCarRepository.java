package com.CarProject.SemiProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CarProject.SemiProject.Entity.UserBookCar;

public interface BookCarRepository  extends JpaRepository<UserBookCar, Integer> {

}
