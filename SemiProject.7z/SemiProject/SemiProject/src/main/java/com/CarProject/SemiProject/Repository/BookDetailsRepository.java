package com.CarProject.SemiProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CarProject.SemiProject.Entity.BookDetails;

public interface BookDetailsRepository extends JpaRepository<BookDetails, Integer> {

}
