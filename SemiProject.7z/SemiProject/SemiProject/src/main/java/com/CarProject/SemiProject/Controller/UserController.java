package com.CarProject.SemiProject.Controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CarProject.SemiProject.Entity.BookDetails;
import com.CarProject.SemiProject.Entity.CarInfo;
import com.CarProject.SemiProject.Entity.DriverDetails;
import com.CarProject.SemiProject.Entity.DriverHotel;
import com.CarProject.SemiProject.Entity.FinalConfirm;
import com.CarProject.SemiProject.Entity.UserBookCar;
import com.CarProject.SemiProject.Entity.UserLogin;
import com.CarProject.SemiProject.Entity.UserRegister;

import com.CarProject.SemiProject.Repository.UserRepository;
import com.CarProject.SemiProject.Security.JwtAuthResponse;
import com.CarProject.SemiProject.Security.JwtTokenHelper;
import com.CarProject.SemiProject.dto.UserDTOLogin;
import com.CarProject.SemiProject.dto.UserDTORegister;
import com.CarProject.SemiProject.service.MainService;


@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired
	private UserRepository userRepository;
	

	
	
	@Autowired
	private MainService mainService;
	
	@Autowired
	private JwtTokenHelper jwtTokenHelper;
	
	
	


	@PostMapping("/login")
	public ResponseEntity<?> logindata(@RequestBody UserDTOLogin userDTOLogin)
	{
		UserLogin user= userRepository.findByUsername(userDTOLogin.getUsername()).get();
		Optional<UserLogin> user1=userRepository.findByUsername(userDTOLogin.getUsername());
	System.out.println(user);
	    if(user.getPassword().equals(userDTOLogin.getPassword())) {
//	    	UserDetails userDetails = this.userDetailsService.loadUserByUsername(userRegister.getUsername());
	    	JwtAuthResponse jwtAuthResponse=new JwtAuthResponse();
	    	jwtAuthResponse.setUser(user1);
	    	String token =this.jwtTokenHelper.generateToken(user.getUsername());
	    	jwtAuthResponse.setToken(token);
	    	return new ResponseEntity<JwtAuthResponse>(jwtAuthResponse,HttpStatus.OK);
	    }
		return ResponseEntity.badRequest().body("fasle");
		
	}
	
	@PostMapping("/Register")
	public ResponseEntity<?> Registerdata(@Valid @RequestBody UserDTORegister userDTORegister)
	{
		Optional<UserLogin> user= userRepository.findByUsername(userDTORegister.getUserName());
		if(user.isEmpty())
		{
		UserRegister userRegister =  mainService.StoreUserRegisterData(userDTORegister);
		JwtAuthResponse jwtAuthResponse=new JwtAuthResponse();
		jwtAuthResponse.setUserRegisterData(userRegister);
		String token = this.jwtTokenHelper.generateToken(userRegister.getUserName());
		jwtAuthResponse.setToken(token);
	    	return new ResponseEntity<JwtAuthResponse>(jwtAuthResponse,HttpStatus.OK);
		}
		else if(user.get().getPassword().equals(userDTORegister.getPassWord())) {
			return ResponseEntity.badRequest().body("you are already register.");
		}
		else {
			UserRegister userRegister =  mainService.StoreUserRegisterData(userDTORegister);
			JwtAuthResponse jwtAuthResponse=new JwtAuthResponse();
			jwtAuthResponse.setUserRegisterData(userRegister);
			String token = this.jwtTokenHelper.generateToken(userRegister.getUserName());
			jwtAuthResponse.setToken(token);
		    	return new ResponseEntity<JwtAuthResponse>(jwtAuthResponse,HttpStatus.OK);
		}
	}
	
	
	@PostMapping("/StoreCarInfo")
	public ResponseEntity<?>  StoreCardata(@RequestBody  CarInfo carInfo)
	{
		CarInfo carInfo1=mainService.StoreCarInfo(carInfo);
		return ResponseEntity.badRequest().body("you are saving your data.");
	}
	
	@GetMapping("/cars")
	public ResponseEntity<?>  data()
	{
		List<CarInfo> carInfo1=mainService.findAll();
		return  ResponseEntity.badRequest().body(carInfo1);
	}
	
	@GetMapping("/cars/{id}")
	public ResponseEntity<?>  carsdata(@PathVariable("id") int id)
	{
		Optional<CarInfo> carInfo1=mainService.findById(id);
		return  ResponseEntity.badRequest().body(carInfo1);
	}
	
	@PostMapping("/book-now")
	public ResponseEntity<?> bookData(@RequestBody UserBookCar userBookCar)
	{
	   CarInfo carInfo=mainService.findById(1).get();
	   mainService.showAllBookDetails(userBookCar, carInfo);
		List<BookDetails> bookDetails=mainService.findAllData();
		return  ResponseEntity.badRequest().body(bookDetails);
	}
	
	@PostMapping("/DriverStore")
	public ResponseEntity<?>  StoreDriver(@RequestBody  DriverDetails  driverDetails)
	{
		
		DriverDetails driverDetails2 =  mainService.save(driverDetails);
		return ResponseEntity.badRequest().body("you are saving your data."+driverDetails2);
	}
	
	@PostMapping("/driver-hotel")
	public ResponseEntity<?>  StoreDrive(@RequestBody  DriverDetails  driverDetails)
	{
		
		DriverDetails driverDetails2 = mainService.save(driverDetails);
		return ResponseEntity.badRequest().body("you are saving your data."+driverDetails2);
	}
	
	@PostMapping("/finalRecord")
	public ResponseEntity<?> StoreFinalRecord(@RequestBody FinalConfirm finalConfirm)
	{
		FinalConfirm finnConfirm= mainService.saveDataConfirm(finalConfirm);
		return ResponseEntity.badRequest().body(finnConfirm);
	}
	
	@GetMapping("/ticket-details/{email}")
	public ResponseEntity<?>  showDataEmailBases(@PathVariable("email") String email)
	{
		List<FinalConfirm> finalConfirm=mainService.finaAllFinalConfirms();
		List<FinalConfirm>finalConfirmResult=finalConfirm.stream().filter(x->x.getEmail().equals(email)).collect(Collectors.toList());
		return  ResponseEntity.badRequest().body("Getting your data:"+finalConfirmResult);
	}
	
	@PostMapping("/StayDetails")
	public ResponseEntity<?> postData(@RequestBody DriverHotel driverHotel)
	{
		DriverHotel driverHotel1=mainService.saveDriverHotel(driverHotel);
		return ResponseEntity.badRequest().body(driverHotel1);
	}
	
}
