package com.CarProject.SemiProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.CarProject.SemiProject.Entity.FinalConfirm;


public interface FinalRecodRepository extends JpaRepository<FinalConfirm, Integer> {

	
}
