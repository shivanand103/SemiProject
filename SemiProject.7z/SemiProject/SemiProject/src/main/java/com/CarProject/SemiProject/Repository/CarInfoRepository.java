package com.CarProject.SemiProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.CarProject.SemiProject.Entity.CarInfo;

@Repository
public interface CarInfoRepository extends JpaRepository<CarInfo,Integer> {

}
