package com.CarProject.SemiProject.ServiceImpl;


import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CarProject.SemiProject.Entity.BookDetails;
import com.CarProject.SemiProject.Entity.CarInfo;
import com.CarProject.SemiProject.Entity.DriverDetails;
import com.CarProject.SemiProject.Entity.DriverHotel;
import com.CarProject.SemiProject.Entity.FinalConfirm;
import com.CarProject.SemiProject.Entity.UserBookCar;
import com.CarProject.SemiProject.Entity.UserLogin;
import com.CarProject.SemiProject.Entity.UserRegister;
import com.CarProject.SemiProject.Repository.BookCarRepository;
import com.CarProject.SemiProject.Repository.BookDetailsRepository;
import com.CarProject.SemiProject.Repository.CarInfoRepository;
import com.CarProject.SemiProject.Repository.DriverDetailsRepository;
import com.CarProject.SemiProject.Repository.DriverHotelRepository;
import com.CarProject.SemiProject.Repository.FinalRecodRepository;
import com.CarProject.SemiProject.Repository.RegisterRepository;
import com.CarProject.SemiProject.Repository.UserRepository;
import com.CarProject.SemiProject.dto.AllBookDetails;
import com.CarProject.SemiProject.dto.UserDTORegister;
import com.CarProject.SemiProject.service.MainService;

@Service
public class ServiceImpl implements MainService {

	
	@Autowired
	private DriverHotelRepository driverHotelRepository;
	
	@Autowired
	private FinalRecodRepository finalRecodRepository;
	
	@Autowired
	private DriverDetailsRepository driverDetailsRepository;
	
	@Autowired
	private CarInfoRepository carInfoRepository;
	
	@Autowired
	private BookDetailsRepository bookDetailsRepository;
	
	@Autowired
	private RegisterRepository registerRepository;
	
	@Autowired
	private   UserRepository userRepository;
	
	@Autowired
	private BookCarRepository bookCarRepository;
	@Override
	public UserRegister StoreUserRegisterData(UserDTORegister userDTORegister) {
		// TODO Auto-generated method stub
		System.out.println(userDTORegister);
		UserRegister userRegister=new UserRegister();
		userRegister.setFirstName(userDTORegister.getFirstName());
		userRegister.setLastName(userDTORegister.getLastName());
		userRegister.setUserName(userDTORegister.getUserName());
		userRegister.setPassWord(userDTORegister.getPassWord());
		
		UserLogin userLogin=new UserLogin();
		userLogin.setUsername(userDTORegister.getUserName());
		userLogin.setPassword(userDTORegister.getPassWord());
		userRepository.save(userLogin);
		registerRepository.save(userRegister);
		return userRegister;
		
	}

	@Override
	public CarInfo StoreCarInfo(CarInfo carInfo) {
		// TODO Auto-generated method stub
		return carInfoRepository.save(carInfo);
	}

	@Override
	public List<CarInfo> findAll() {
		// TODO Auto-generated method stub
		return carInfoRepository.findAll();
	}

	@Override
	public Optional<CarInfo> findById(int id) {
		
		return carInfoRepository.findById(id);
	}

	@Override
	public UserBookCar storeBookCar(UserBookCar userBookCar) {
		// TODO Auto-generated method stub
		return bookCarRepository.save(userBookCar);
	}

	@Override
	public void showAllBookDetails(UserBookCar userBookCar, CarInfo carInfo) {
		// TODO Auto-generated method stub
		BookDetails allBookDetails=new BookDetails();
		allBookDetails.setCarCompany(carInfo.getCarCompany());
		allBookDetails.setCarColor(carInfo.getCarColor());
		allBookDetails.setCarModel(carInfo.getCarModel());
		allBookDetails.setCarType(carInfo.getCarType());
		allBookDetails.setCarOwner(carInfo.getCarOwner());
		allBookDetails.setCarImg(carInfo.getCarImg());
		allBookDetails.setNumPlate(carInfo.getNumPlate());
		allBookDetails.setInsuranceValidity(carInfo.getInsuranceValidity());
		allBookDetails.setFuelType(carInfo.getFuelType());
		allBookDetails.setFeature(carInfo.getFeature());
		allBookDetails.setPickUpLocation(userBookCar.getPickUpDate());
		allBookDetails.setDropLocation(userBookCar.getDropLocation());
		allBookDetails.setPickUpTime(userBookCar.getPickUpTime());
		allBookDetails.setPickUpDate(userBookCar.getPickUpDate());
		allBookDetails.setDropDate(userBookCar.getDropDate());
		allBookDetails.setPassangerCapacity(userBookCar.getPassangerCapacity());
		allBookDetails.setMembers(userBookCar.getMembers());
		allBookDetails.setDays(userBookCar.getDays());
		allBookDetails.setNumBags(userBookCar.getNumBags());
		allBookDetails.setTotalPrice(carInfo.getTotalPrice());
		allBookDetails.setCarId(carInfo.getCarId());
		bookDetailsRepository.save(allBookDetails);
	}

	@Override
	public List<BookDetails> findAllData() {
		// TODO Auto-generated method stub
		return bookDetailsRepository.findAll();
	}

	@Override
	public DriverDetails save(DriverDetails driverDetails) {
		// TODO Auto-generated method stub
		return driverDetailsRepository.save(driverDetails);
	}

	@Transactional
	@Override
	public FinalConfirm saveDataConfirm(FinalConfirm finalConfirm) {
		// TODO Auto-generated method stub
		return finalRecodRepository.save(finalConfirm);
	}

	@Override
	public List<FinalConfirm> finaAllFinalConfirms() {
		// TODO Auto-generated method stub
		return finalRecodRepository.findAll();
	}

	@Override
	public DriverHotel saveDriverHotel(DriverHotel driverHotel) {
		// TODO Auto-generated method stub
		return driverHotelRepository.save(driverHotel);
	}

	

}
